#include <stdio.h>
#include "sys/alt_stdio.h"
#include "altera_avalon_pio_regs.h" // include for reg32 avalon interfaces
#include "system.h"		// includes all register addresses for components on Nios II system
#include "sqrt_csr.h" // This header file describes the CSR Slave for the sqrt component

// floorsqrt returns an integer squareroot
// If the input is not a perfect square, it will return an answer that's nearest integer rounded towards the lesser value.
int floorsqrt(int input);


int main() {
	alt_putstr("Hello from Nios!\n");

	int radicand =  41; // number to be squarerooted

    int answer = floorsqrt(radicand); // first time to flush pipeline
    printf("\nradicand: %d", radicand);
    answer = floorsqrt(radicand);
    printf("\nfloorsqrt(%d): %d", radicand, answer);


	// loop does not terminate
	while(1){};

	return 0;
}

int floorsqrt(int input){
	int returnvalue = 0;
	// reading done status from sqrt interrupt status
	int done = 2 & IORD_ALTERA_AVALON_PIO_DATA(SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_INTERRUPT_STATUS_REG);

	// pass squareroot argument to hls component (input)
	IOWR_ALTERA_AVALON_PIO_DATA(SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_ARG_X_REG,
			input & SQRT_CSR_ARG_X_MASK);
	// send start signal to hls component
	IOWR_ALTERA_AVALON_PIO_DATA(SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_START_REG, 1);

	// check if hls component is done and not busy
	while(!done){
		done = 2 & IORD_ALTERA_AVALON_PIO_DATA(SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_INTERRUPT_STATUS_REG);
	}

	// if done, set the return value
	if(done){
		returnvalue = IORD_ALTERA_AVALON_PIO_DATA((SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_RETURNDATA_REG)&SQRT_CSR_RETURNDATA_MASK);
	}

	// reset the floorsqrt component by writing 1 to the interrupt status reg
	IOWR_ALTERA_AVALON_PIO_DATA(SQRT_0_SQRT_INTERNAL_INST_BASE+SQRT_CSR_INTERRUPT_STATUS_REG, 1);

	return returnvalue;
}
